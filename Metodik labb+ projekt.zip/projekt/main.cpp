#include <SFML/Graphics.hpp>
#include "BouncingCube.h"


int main()
{
    std::srand(time(NULL));
    sf::RenderWindow window(
        sf::VideoMode(sf::Vector2u{1200u, 800u}),
        "Bouncing Cube",
        sf::Style::Default
    );
   
   window.setPosition(sf::Vector2i{0,0});

    sf::Clock clock;

    BouncingCube cube(window.getSize(), sf::Vector2f{70.f, 70.f}, 23.f);

    while (window.isOpen())
    {
    float dt = clock.restart().asSeconds();

    cube.update(dt);


    
    while (auto eventOpt = window.pollEvent())
    {
        const sf::Event& event = *eventOpt;
        
    const float lineSpeed = 1000.f; 

    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Left) ||
    sf::Keyboard::isKeyPressed(sf::Keyboard::Key::A))
    {
    cube.moveLine(-lineSpeed * dt);
    }

    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Right) ||
    sf::Keyboard::isKeyPressed(sf::Keyboard::Key::D))
    {
    cube.moveLine(lineSpeed * dt);
    }
               

        if (event.is<sf::Event::Closed>())
            window.close();
    }

    window.clear();
    cube.draw(window);
    window.display();
    }


    return 0;
}