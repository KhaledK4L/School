var searchData=
[
  ['funktioner_0',['Funktioner',['../index.html#autotoc_md1',1,'']]]
];
