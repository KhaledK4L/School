var searchData=
[
  ['externt_20bibliotek_0',['Externt bibliotek',['../index.html#autotoc_md2',1,'']]]
];
