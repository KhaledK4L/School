#pragma once
#include <SFML/Graphics.hpp>
#include <random>

class BouncingCube
{
public:
    BouncingCube(const sf::Vector2u& windowSize,
                 const sf::Vector2f& size,
                 float speed);
    void setSpeed(float speed);
    void update(float dt);
    void draw(sf::RenderWindow& window);
    void moveLine(float dx);

private:
    sf::Vector2u m_windowSize;
    sf::RectangleShape m_cube;
    sf::Vector2f m_velocity;
    float m_speed;

    sf::RectangleShape m_line;


    void randomizePosition();
};
