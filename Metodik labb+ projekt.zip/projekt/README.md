# BouncingCube

BouncingCube är en enkel SFML-app som visar en kvadrat/kub som studsar i ett fönster.

## Funktioner
- Öppnar ett fönster med SFML
- Ritar en kub (rectangle shape)
- Uppdaterar position varje frame
- Studsar mot kanterna

## Externt bibliotek
- SFML (Graphics, Window, System)

## Bygg & kör
```bash
mkdir build
cmake -S . -B build
cmake --build build -j
./build/BouncingCube