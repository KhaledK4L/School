#include "BouncingCube.h"
#include <cstdlib> 


BouncingCube::BouncingCube(const sf::Vector2u& windowSize, 
                           const sf::Vector2f& size,
                           float speed)
    : m_windowSize(windowSize), m_speed(speed)
{
    m_cube.setSize(size);
    m_cube.setFillColor(sf::Color::Red);

    
    randomizePosition();

    
    m_velocity = { speed, speed };
    
    

    const float thickness = 6.f;
    m_line.setSize({ thickness, (float)m_windowSize.y });
    m_line.setFillColor(sf::Color::White);
    m_line.setPosition({ (float)m_windowSize.x / 2.f - thickness / 2.f, 0.f });


   
}


void BouncingCube::setSpeed(float speed)
{
    m_speed = speed;
}





void BouncingCube::update(float dt)
{
    
    sf::Vector2f step = m_velocity * m_speed * dt;
    m_cube.move(step);

   
    sf::Vector2f pos  = m_cube.getPosition();
    sf::Vector2f cubeSize = m_cube.getSize();

    
    if (m_cube.getGlobalBounds().findIntersection(m_line.getGlobalBounds()))
    {
        randomizePosition();
        m_velocity.x = -m_velocity.x; 
        return; 
    }

    
    if (pos.x < 0.f)
    {
        pos.x = 0.f;
        m_velocity.x = -m_velocity.x;
    }
    else if (pos.x + cubeSize.x > (float)m_windowSize.x)
    {
        pos.x = (float)m_windowSize.x - cubeSize.x;
        m_velocity.x = -m_velocity.x;
    }

    
    if (pos.y < 0.f)
    {
        pos.y = 0.f;
        m_velocity.y = -m_velocity.y;
    }
    else if (pos.y + cubeSize.y > (float)m_windowSize.y)
    {
        pos.y = (float)m_windowSize.y - cubeSize.y;
        m_velocity.y = -m_velocity.y;
    }

    
    m_cube.setPosition(pos);
}





void BouncingCube::draw(sf::RenderWindow& window)
{
    window.draw(m_cube);
    window.draw(m_line);


}


void BouncingCube::moveLine(float dx)
{
    sf::Vector2f p = m_line.getPosition();
    p.x += dx;

    
    float maxX = (float)m_windowSize.x - m_line.getSize().x;
    if (p.x < 0.f) p.x = 0.f;
    if (p.x > maxX) p.x = maxX;

    m_line.setPosition(p);
}



void BouncingCube::randomizePosition()
{
    m_cube.setPosition(sf::Vector2f(
        rand() % (m_windowSize.x - (unsigned)m_cube.getSize().x),
        rand() % (m_windowSize.y - (unsigned)m_cube.getSize().y)
    ));
}
