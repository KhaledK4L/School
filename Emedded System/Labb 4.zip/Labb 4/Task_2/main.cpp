// Exercise 5: Liquid Crystal Displays
// Sub-task 2: Display bitmaps
#include "mbed.h"
#include "C12832A1Z.h"

C12832A1Z lcd(p5, p7, p6, p8, p11);

// Create joystick buttons with PullDown mode (pressed = 1, not pressed = 0).
DigitalIn joy_down(p12, PullDown);
DigitalIn joy_left(p13, PullDown);
DigitalIn joy_center(p14, PullDown);
DigitalIn joy_up(p15, PullDown);
DigitalIn joy_right(p16, PullDown);

// Screen size (C12832A1Z = 128x32 pixels), W = Width and H = Height.
const int LCD_W = 128, LCD_H = 32;

// Sprite size (W,H) and a 12x12 bird (1 = pixel, 0 = empty).
const int W = 12, H = 12;
static const uint8_t BIRD_R[H][W] = 
{
   {0,0,1,1,1,1,1,0,0,0,0,0},
   {0,0,0,1,1,1,1,1,1,0,0,0},
   {0,0,0,0,0,1,1,1,0,0,0,0},
   {0,0,0,0,1,1,1,0,0,0,0,0},
   {1,1,1,1,1,1,1,1,1,1,0,0},
   {0,1,1,1,1,1,1,1,1,1,1,1},
   {0,1,1,1,1,1,1,1,1,1,1,1},
   {1,1,1,1,1,1,1,1,1,1,0,0},
   {0,0,0,0,1,1,1,0,0,0,0,0},
   {0,0,0,0,0,1,1,1,0,0,0,0}, 
   {0,0,0,1,1,1,1,1,1,0,0,0},
   {0,0,1,1,1,1,1,0,0,0,0,0},
};

// Draw one pixel using a 1x1 filled rect.
static inline void px(int x,int y){ lcd.fillrect(x,y,x,y,(color_t)1); }

// Draw the whole sprite at (x,y). Two loops go over rows and columns.
void draw_sprite(const uint8_t s[H][W], int x, int y)
{
    for(int r=0;r<H;r++) 
    for(int c=0;c<W;c++) 
    if(s[r][c]) px(x+c,y+r);
}

int main()
{
    // Give LCD time to start, then clear once
    wait_ms(150);
    lcd.cls();

    int x=0, y=0;  
    // Infinite loop: repeats the block forever
    while(1)
    {
        // Clear screen to white each frame
        lcd.fillrect(0,0,127,31,(color_t)0);

        // Read joystick and move 1 pixel in the pressed direction
        if(joy_left.read()==1)  x--;
        if(joy_right.read()==1) x++;
        if(joy_up.read()==1)    y--;
        if(joy_down.read()==1)  y++;

        // Center button: reset to middle
        if (joy_center.read()) 
        {
            x = 0;
            y = 0;
        }

        // Keep the sprite inside the 128x32 display area
        if(x < 0) x = 0; 
        if(y < 0) y = 0;
        if(x > LCD_W - W) x = LCD_W - W; 
        if(y > LCD_H - H) y = LCD_H - H;

        // Draw the bird at the new position
        draw_sprite(BIRD_R, x, y);

        // Small delay so movement looks smooth
        wait_ms(25);
    }
}
