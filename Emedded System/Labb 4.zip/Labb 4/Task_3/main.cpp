// Exercise 5: Liquid Crystal Displays (C12832A1Z + LM75B)
// Sub-task 3: Display graphs

#include "mbed.h"
#include "C12832A1Z.h"
#include "LM75B.h"


C12832A1Z lcd(p5, p7, p6, p8, p11);

// LM75B temperature sensor on the app board (I2C SDA = Serial Data , 12C SCL = Serial Clock).
LM75B sensor(p28, p27);

// Graph area (X0,Y0,GW = Graph Width, GH = Graph Height) and temperature range (T_MIN..T_MAX) for the Y-axis.
const int X0 = 22, Y0 = 4;
const int GW = 100, GH = 24;
float T_MIN = 15.0f, T_MAX = 35.0f;

// This function converts a temperature in °C to a Y-pixel inside the graph.
int temp_to_y(float t) 
{
    if (t < T_MIN) t = T_MIN;
    if (t > T_MAX) t = T_MAX;
    float r = (t - T_MIN) / (T_MAX - T_MIN);
    int bottom = Y0 + GH - 1;
    return bottom - (int)(r * (GH - 1));
}

// This function clears the screen, draws the graph frame, and prints simple labels.
void draw_axes() 
{
    // Clear the screen and draw the graph frame (top, bottom, left, and right borders).
    lcd.cls();
    lcd.fillrect(X0-1,   Y0-1,   X0+GW,  Y0-1,   (color_t)1);
    lcd.fillrect(X0-1,   Y0+GH,  X0+GW,  Y0+GH,  (color_t)1);
    lcd.fillrect(X0-1,   Y0-1,   X0-1,   Y0+GH,  (color_t)1);
    lcd.fillrect(X0+GW,  Y0-1,   X0+GW,  Y0+GH,  (color_t)1);

    // Place labels: show max, mid, and min temperatures on the left, a title at the top, and "Time" at the bottom-right of the graph.
    lcd.locate(0, 0);  lcd.printf("%2.0f", T_MAX);
    lcd.locate(0, 15); lcd.printf("%2.0f", (T_MIN + T_MAX)/2);
    lcd.locate(0, 26); lcd.printf("%2.0f", T_MIN);
    lcd.locate(X0, 0); lcd.printf("Temp graph");
    lcd.locate(X0 + GW - 24, 26); lcd.printf("Time");
}

int main() 
{
    wait_ms(150); 

       // Run forever and start a new graph sweep each time.            
    while (1) 
    {                      
        draw_axes();
        int x = 0;                   

        // Plot one new temperature point per second across the graph width.
        while (x < GW) 
        {             
            float T = sensor.read();                         // Read temperature in °C.
            lcd.locate(70, 0); lcd.printf("%2.2fC  ", T);

            int y = temp_to_y(T);                            // Convert temperature to Y pixel.  
            lcd.fillrect(X0 + x, y, X0 + x, y, (color_t)1);  // Draw one pixel.

            x++;
            wait_ms(1000);           
        }
       
    }
}
