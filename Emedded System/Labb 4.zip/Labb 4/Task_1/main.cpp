// Exercise 5: Liquid Crystal Displays
// Sub-task 1: Display texts

#include "mbed.h"
#include "C12832A1Z.h"

// Setup LCD display and potentiometer input.
C12832A1Z lcd(p5, p7, p6, p8, p11);
AnalogIn pot(p19);

int main() 
{
    /* Give the LCD time to power up, then clear it.
       Move the cursor to (0,0) and print the title text. */
    wait_ms(150);
    lcd.cls();
    lcd.locate(0, 0);
    lcd.printf("Voltmeter 0-3.3V");
    /* Continuously read the potentiometer value, convert it to volts,
       display the result on the LCD, and update every 200 ms. */
    while (1) 
    {
        float volt = pot.read() * 3.3f;
        lcd.locate(0, 15);
        lcd.printf("U = %1.3f V   ", volt);
        wait_ms(200);
    }
}
