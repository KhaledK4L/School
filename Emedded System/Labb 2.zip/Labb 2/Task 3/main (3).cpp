// Exercise 2: Analog Inputs and Outputs
// Sub-task 3: AnalogIn

#include "mbed.h"

// Create analog input for the potentiometer
AnalogIn pot(p19);

// Create serial connection to the computer
Serial pc(USBTX, USBRX);

int main() {
    // Set baud rate for the terminal
    pc.baud(9600);

    // Infinite loop: read the potentiometer and show the value
    while (true) {
        float sum = 0.0f;

        /* For loop: take 20 readings to make the value more stable
        and convert ADC value (0..1) into voltage (0..3.3V)*/
        for (int i = 0; i < 20; i++) {
            sum += pot.read() * 3.3f;   
        }

        /* Calculate the average voltage from the 20 samples. 
        And print the voltage to the terminal*/
        float voltage = sum / 20.0f;
        pc.printf("Potentiometer voltage: %.2f V\r\n", voltage);

        wait(1.0);  
    }
}
