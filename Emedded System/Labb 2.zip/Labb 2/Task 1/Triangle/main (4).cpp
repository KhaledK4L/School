// Exercise 2: Analog Inputs and Outputs
// Sub-task 1: Triangle waveform

#include "mbed.h"

AnalogOut dac(p18);   // DAC output pin

int main() {
    // Waveform setup: target 2 Vpp scaled to DAC (0..1), resolution, and per-step increment.
    const float Vpp = 2.0f;       
    const float maxValue = Vpp / 3.3f;  
    const int steps = 100;        
    const float step = maxValue / steps;

    // Step delay chosen so the overall period is close to 100 Hz.
    int delay_us = 45;  

    // Main loop: continuously generate triangle waves.
    while (true) {
        float level = 0.0f;

        // Rising slope: increase the DAC output in 'steps' small increments.
        for (int i = 0; i <= steps; i++) 
        {
            dac.write(level);
            level += step;
            wait_us(delay_us);
        }

        // Falling slope: decrease the DAC output back down in 'steps'.
        for (int i = 0; i <= steps; i++) 
        {
            dac.write(level);
            level -= step;
            wait_us(delay_us);
        }
    }
}
