// Exercise 2: Analog Inputs and Outputs
// Sub-task 1: Sawtooth waveform

#include "mbed.h"

AnalogOut dac(p18);   // DAC output pin on mbed

int main() 
{
    // These constants define the waveform: target 2 Vpp, scale to DAC (0..1), resolution, and step size.
    const float Vpp = 2.0f;            
    const float maxValue = Vpp / 3.3f; 
    const int steps = 100;             
    const float step = maxValue / steps;

    // This value sets the per-step delay so the output is close to 100 Hz.
    int delay_us = 50;   

    // Main loop continuously generates the sawtooth waveform.
    while (true) 
    {
        float level = 0.0f;

        // This loop creates the rising slope by stepping the DAC from 0 up to the max value.
        for (int i = 0; i <= steps; i++) 
        {
            dac.write(level);  
            level += step;      
            wait_us(delay_us);  
        }

        // This single write performs the instant drop back to zero to start the next cycle.
        dac.write(0.0f);
    }
}
