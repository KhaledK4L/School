// Exercise 2: Analog Inputs and Outputs
// Sub-task 1: Sine waveform

#include "mbed.h"
#include <cmath>

AnalogOut dac(p18);   // DAC output pin

int main() {
    // Configure waveform: resolution (samples per cycle), math constant, and target frequency.
    const int samples = 100;
    const float pi = 3.14159f;
    const float freq = 100.0f;

    // Main loop: continuously generate the sine wave forever.
    while (true) {
        // One full cycle: step through 'samples' points to output a 100 Hz sine.
        for (int i = 0; i < samples; i++) {
            float y = 0.5f + 0.5f * sinf(2 * pi * i / samples); // 0..1
            dac.write(y * (2.0f / 3.3f));                       // ~2 Vpp
            wait_us(1000000 / (freq * samples));                // timing per sample
        }
    }
}
