// Exercise 2: Analog Inputs and Outputs
// Sub-task 2: PWM (Pulse Width Modulation) fading RGB LED (white light)

#include "mbed.h"

// Create RGB LED pinsn for the output 
PwmOut red(p23);
PwmOut green(p24);
PwmOut blue(p25);

int main() {
    // Set PWM speed for the LEDs (about 500 Hz)
    red.period_ms(2);
    green.period_ms(2);
    blue.period_ms(2);
    
    // Infinite loop: repeatedly fade the RGB LED in and out with white light
    while (true) {
        // For loop: gradually increase brightness over ~2 seconds (fade in)
        for (float d = 0.0f; d <= 1.0f; d += 0.01f) {
            red = green = blue = 1.0f - d;  
            wait_ms(20);  
        }

        // For loop: gradually decrease brightness over ~2 seconds (fade out)
        for (float d = 1.0f; d >= 0.0f; d -= 0.01f) {
            red = green = blue = 1.0f - d;
            wait_ms(20);
        }
    }
}
