#include "C12832.h"
#include "mbed.h"

// Define the I2C pins
I2C sensor(p28, p27);

// LCD configuration
C12832 lcd(p5, p7, p6, p8, p11);

// Filesystem for highscore management
LocalFileSystem local("local");

// Digital input for the joystick (used for menu navigation)
DigitalIn up(p15);
DigitalIn down(p12);
DigitalIn center(p14);

// Analog input of the potentiometer (for LCD refresh speed control)
AnalogIn pot(p19);

// Timers
Timer lcd_timer;
Timer game_timer;

// Bitmaps for rectangle and star (catching object)
// Updated the rectangle size
static char rectangle_bm[] = {
    0x00, 0x3F, 0xC0,   // New smaller rectangle
    0x07, 0xFF, 0xF0,   
    0x1F, 0xFF, 0xFC,   
    0x1F, 0xFF, 0xFC,   
    0x1F, 0xFF, 0xFC,   
    0x07, 0xFF, 0xF0,   
    0x00, 0x3F, 0xC0,   
};

static char star_bm[] = {
    0x70, 
    0x88, 
    0x88, 
    0x88, 
    0x70
};

// Bitmap dimensions for new rectangle size
const int RECTANGLE_WIDTH = 16;  // Changed width of rectangle
const int RECTANGLE_HEIGHT = 6;  // Changed height of rectangle
const int STAR_WIDTH = 5;
const int STAR_HEIGHT = 5;

// Bitmap structure
const Bitmap rectangle = {RECTANGLE_WIDTH, RECTANGLE_HEIGHT, 3, rectangle_bm}; 
const Bitmap star = {STAR_WIDTH, STAR_HEIGHT, 1, star_bm};

// LCD and screen dimensions
const int SCREEN_WIDTH = 128;
const int SCREEN_HEIGHT = 32;

// I2C address for Accelerometer
const int MMA_ADDRESS = 0x98; 

// Function to set the sensor in standby mode
void set_mma7660_standby() {
    char data[2] = {0x07, 0x00};  
    sensor.write(MMA_ADDRESS, data, 2);
    wait_us(500);
}

// Function to set the sensor in active mode
void set_mma7660_active() {
    char data[2] = {0x07, 0x01};
    sensor.write(MMA_ADDRESS, data, 2);
    wait_us(500); 
}

// Function to display menu
void display_menu(int option) {
    lcd.locate(0, 0);
    switch (option) {
        case 1:
            lcd.printf("> Start game\n");
            lcd.printf("  Highscore");
            break;
        case 2:
            lcd.printf("  Start game\n");
            lcd.printf("> Highscore");
            break;
        case 3:
            lcd.printf("> Try again\n");
            lcd.printf("  Menu");
            break;
        case 4:
            lcd.printf("  Try again\n");
            lcd.printf("> Menu");
            break;
    }
}

// File management for highscore
void manage_highscore(int option, int score) {
    FILE *file;
    if (option == 1) {  // Write new score if it's higher
        int current_highscore = 0;
        file = fopen("/local/textfile.txt", "r");
        if (file) {
            fscanf(file, "%d", &current_highscore);
            fclose(file);
        }
        if (score > current_highscore) {
            file = fopen("/local/textfile.txt", "w");
            fprintf(file, "%d", score);
            fclose(file);
        }
    } else if (option == 2) {  
        file = fopen("/local/textfile.txt", "r");
        if (file) {
            int current_highscore;
            fscanf(file, "%d", &current_highscore);
            fclose(file);
            lcd.cls();
            lcd.locate(0, 0);
            lcd.printf("Press button to return");
            lcd.printf("\nHighscore is: %d", current_highscore);
            wait(0.5);
            while(!center) {}
        } else {
            lcd.printf("No high score recorded yet.\n");
        }
        wait(0.5);
        lcd.cls();
    }
}

// Function to read accelerometer data
float read_accel(char reg) {
    char data;
    float accel;
    sensor.write(MMA_ADDRESS, &reg, 1,true); 
    sensor.read(MMA_ADDRESS, &data, 1);   
    int8_t accel_int = data;
    if (accel_int > 31)
        accel = -1.5+(accel_int-31)*0.047; 
    else
        accel = accel_int*0.047;
    return accel;
}

// Function to check for collision
bool hit_hitbox(int rectangle_x, int rectangle_y, int star_x, int star_y) {
    bool overlap_x = (rectangle_x < star_x + STAR_WIDTH) && (rectangle_x + RECTANGLE_WIDTH > star_x);
    bool overlap_y = (rectangle_y < star_y + STAR_HEIGHT) && (rectangle_y + RECTANGLE_HEIGHT > star_y);
    return overlap_x && overlap_y;
}

// Function to spawn a new star at random X position
int spawn_new_star(int rectangle_position) {
    int position;
    do {
        position = (rand() % (SCREEN_WIDTH - STAR_WIDTH));
    } while(position == rectangle_position); // Ensure the star doesn't spawn at the rectangle's position
    return position;
}

// End game menu handling
int handle_end_menu() {
    bool end_selected = false;
    int end_option = 3;
    while (!end_selected) {
        display_menu(end_option);
        if (up) 
            end_option = 3;
        if (down) 
            end_option = 4;
        if (center) 
            end_selected = true;
    }
    return end_option;
}

// Game logic for falling stars
void game() {
    lcd_timer.start();
    game_timer.start();
    lcd_timer.reset();
    game_timer.reset();

    float in_game_time = 5;
    bool gameover = false;
    int score = 0;
    int missed_stars = 0; // Variable to count missed stars

    int rectangle_x = 60;  // Initial position of rectangle
    int rectangle_y = SCREEN_HEIGHT - RECTANGLE_HEIGHT;  // Place it at the bottom of the screen
    int star_x = spawn_new_star(rectangle_x);
    int star_y = 0;  // Start from top of the screen

    while (!gameover) {
        float pot_value = pot.read();
        float refresh_lcd = pot_value * (0.2 - 0.01) + 0.01;

        if (lcd_timer.read() >= refresh_lcd) {
            float x_acc = read_accel(0x00);
            float y_acc = read_accel(0x01);

            // Modify the speed of rectangle's movement by increasing movement speed
            if (x_acc < -0.1 && rectangle_x > 0)
                rectangle_x -= 2;  // Increased speed (was 1)
            if (x_acc > 0.1 && rectangle_x < SCREEN_WIDTH - RECTANGLE_WIDTH)
                rectangle_x += 2;  // Increased speed (was 1)

            // Move the falling star down
            star_y += 1;  

            // Check for collision
            bool star_hit = hit_hitbox(rectangle_x, rectangle_y, star_x, star_y);         
            if (star_hit) {
                star_x = spawn_new_star(rectangle_x);
                star_y = 0;
                score += 100;

                if (in_game_time >= 1)
                    in_game_time -= 0.25;

                game_timer.reset();  // Reset game timer after catching a star
            }

            // Reset the star if it goes off the screen
            if (star_y >= SCREEN_HEIGHT) {
                star_y = 0;
                star_x = spawn_new_star(rectangle_x);
                missed_stars++; // Increment missed stars

                // End the game if 5 stars are missed
                if (missed_stars >= 5) {
                    gameover = true;  // Game over condition after missing 5 stars
                }
            }

            lcd.cls();
            lcd.print_bm(rectangle, rectangle_x, rectangle_y);
            lcd.print_bm(star, star_x, star_y);
            lcd.copy_to_lcd();

            lcd_timer.reset();  // Reset timer for LCD refresh
        }
    }

    lcd_timer.stop();
    game_timer.stop();

    lcd.cls();
    lcd.locate(40, 15);
    lcd.printf("Score: %d", score);
    wait(3);

    lcd.cls();
    manage_highscore(1, score);

    int end_menu_choice = handle_end_menu();
    wait(0.5);

    if (end_menu_choice == 3) 
        game();
}

int main() {
    int choice = 1;

    while (1) {
        display_menu(choice);
        if (up == 1) 
            choice = 1;
        if (down == 1) 
            choice = 2;
        if (center == 1) {
            if (choice == 1){
                set_mma7660_active();
                game();
                set_mma7660_standby();
            } else {
                manage_highscore(2, 0);
            }
        }
        wait(0.1);
    }
}
