// Exercise 4: Time and Events
// Sub-task 3: Timeouts (random delay 5..10 s)

#include "mbed.h"
#include <cstdlib>

// Serial and the pins/timers we use in this task
Serial USB(USBTX, USBRX);
InterruptIn joy_center(p14);
Ticker one_sec;      // prints every second
Timeout done;        // runs once when time is over

// Shared data for the countdown
volatile int remaining = 0;      
volatile bool running = false;   

// If-statement block: runs every second while the timer is on
void tick_second() 
{
    if (running) 
    {
        USB.printf("Remaining: %d s\r\n", remaining);
        if (--remaining <= 0) 
        {
            one_sec.detach();    // stop the 1 s ticker at zero
        }
    }
}

// Simple end message when the timeout finishes
void on_done() 
{
    USB.printf("Time is up!\r\n");
    running = false;
}

// Button press block: start a new random delay (ignore if already running)
void on_press() 
{
    if (running) return;

    // Make a random seed so we get a different delay each time 
    static Timer seedT;
    if (!seedT.read_ms()) { seedT.start(); }
    srand(seedT.read_us());

    // Pick a delay between 5 and 10 seconds 
    remaining = 5 + (rand() % 6);
    USB.printf("Starting delay: %d s\r\n", remaining);

    // Start the 1 s ticker and the one-shot timeout 
    running = true;
    one_sec.attach(&tick_second, 1.0);
    done.attach(&on_done, remaining);
}

int main() {
    // Serial speed for the terminal
    USB.baud(9600);

    // Set the joystick button and connect the press function
    joy_center.mode(PullDown);
    joy_center.rise(&on_press);

    // Main loop: do nothing here, timers/interrupts do the work
    while (true) { wait_ms(20); }
}
