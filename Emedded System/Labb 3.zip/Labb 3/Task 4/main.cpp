// Exercise 4: Time and Events
// Sub-task 4: Tickers 

#include "mbed.h"

DigitalOut led1(LED1), led2(LED2), led3(LED3), led4(LED4);
Ticker t1, t2, t3, t4;

// ISR: simple togglers called by their tickers
void tog1(){ led1 = !led1; }
void tog2(){ led2 = !led2; }
void tog3(){ led3 = !led3; }
void tog4(){ led4 = !led4; }

int main() 
{
    // Attach tickers at half the target period, since toggling each time gives full blink period
    // (toggle every T/2 → ON→OFF takes T seconds total)
    t1.attach(&tog1, 0.7f / 2.0f);  
    t2.attach(&tog2, 1.2f / 2.0f);  
    t3.attach(&tog3, 2.3f / 2.0f);  
    t4.attach(&tog4, 3.9f / 2.0f);  

    // The main loop remains empty as required
    while (true) { }
}
