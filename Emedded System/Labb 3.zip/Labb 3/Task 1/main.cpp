// Exercise: Timers & Interrupts
// Sub-task 1: External Interrupts

#include "mbed.h"

// Create LEDs, joystick button input, and ticker for blinking
DigitalOut led1(LED1), led2(LED2), led3(LED3);
InterruptIn joy_center(p14);
Ticker blinker;

// Functions that run when events happen
void on_press()  { led2 = !led2; }     
void on_release(){ led3 = !led3; }     
void toggle_led1(){ led1 = !led1; }    

int main() 
{
    /* Setup: joystick input with pull-down. 
       Connect press/release to functions, 
       and start LED1 blink every 0.5s*/
    joy_center.mode(PullDown);        
    joy_center.rise(&on_press);       
    joy_center.fall(&on_release);     
    blinker.attach(&toggle_led1, 0.5);

    // Infinite loop: program runs but most work is done in interrupts
    while (true) 
    {
        wait_ms(10);   // small wait so CPU is not 100% busy
    }
}
