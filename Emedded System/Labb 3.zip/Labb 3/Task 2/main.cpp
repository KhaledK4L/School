// Exercise: Timers & Interrupts
// Sub-task 2: Timers

#include "mbed.h"
#include <cstring>

// Create serial connection to the computer
Serial USB(USBTX, USBRX);

int main() 
{
    // Set baud rate and make a buffer for the text
    USB.baud(9600);
    char buf[128] = {0};

    // Ask the user to type a word and save it in the buffer
    USB.printf("Type a word (no spaces), then press Enter:\r\n");
    USB.scanf("%127s", buf);
    int n = strlen(buf);

    // Create a timer and start it before printing the word back
    Timer t;
    USB.printf("Echo:\r\n");
    t.start();

    /* For loop: print the word one character at a time. 
       The timer is running while we do this */
    for (int i = 0; i < n; i++) 
    {
        USB.putc(buf[i]);
    }
    USB.putc('\r'); USB.putc('\n');

    // Stop the timer when done printing
    t.stop();

    /* Calculate the total time, number of characters, 
       and average time per character. Then print the result */
    float total_us = t.read_us();
    float avg_us_per_char = (n > 0) ? (total_us / n) : 0.0f;
    USB.printf("Total: %.0f us, Chars: %d, Avg per char: %.1f us\r\n",
              total_us, n, avg_us_per_char);

    // Infinite loop: keep program running
    while (true) { wait(1.0); }
}
