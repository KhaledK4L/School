// Exercise 1, Sub-task 3: Joystick with BusIn/BusOut
#include "mbed.h"

// LEDs as a 4-bit bus (LED1->bit0 ... LED4->bit3)
BusOut leds(LED1, LED2, LED3, LED4);

// Joystick as a 5-bit bus: Left, Up, Right, Down, Center
// Pins on the Application Board: p13, p15, p16, p12, p14
BusIn joy(p13, p15, p16, p12, p14);

int main() {
    joy.mode(PullDown);   // released=0, pressed=1
    leds = 0;
    int prev = 0;         // last joystick state (5 bits)

    // Loop: read joystick every 20 ms. Detect new presses (rising edges).
    // If Center is pressed, clear all LEDs. Otherwise toggle the matched LED.
    while (true) {
        wait_ms(20);
        int now   = joy.read();
        int edges = (now ^ prev) & now;   // rising edges only
        prev = now;

        if (edges & (1 << 4)) {           // Center
            leds = 0;
        } else {
            leds = leds ^ (edges & 0x0F); // L,U,R,D -> LED1..LED4
        }
    }
}
