// Exercise 1, Sub-task 3: LEDs with BusOut
#include "mbed.h"

// 4 LEDs combined as a 4-bit bus (bit0=LED1 ... bit3=LED4)
BusOut leds(LED1, LED2, LED3, LED4);

int main() {
    int i = 0;  // current LED index (0..3)

    // Loop: every second, toggle exactly one LED in sequence (LED1→LED4→repeat)
    while (true) {
        int mask = 1 << i;
        leds = leds ^ mask;
        wait(1.0);
        i = (i + 1) % 4;
    }
}
