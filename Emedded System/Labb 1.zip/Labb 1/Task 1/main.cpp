// Exercise 1, Sub-task 1: LEDs 
#include "mbed.h"

// Create DigitalOut array objects for the four on-board LEDs.
DigitalOut led[]= {LED1, LED2, LED3, LED4};

int main() 
{
    // Infinite while loop that continuously executes the for loops. 
    while (true) 
    {
        // Turn on the LED1 to LED4 one by one.
        for (int i=0; i<4; i++) 
        {
         led[i]=1;
         wait(1);
        }

        // Turn off the LED1 to LED4 one by one.
        for (int i=0; i<4; i++) 
        {
         led[i]=0;
         wait(1);
        }
    } 
}
