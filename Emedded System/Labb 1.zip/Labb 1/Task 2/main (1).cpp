// Exercise 1, Sub-task 2: Joystick
#include "mbed.h"

// LEDs (on-board)
DigitalOut led1(LED1);
DigitalOut led2(LED2);
DigitalOut led3(LED3);
DigitalOut led4(LED4);

// Joystick pins (Application Board, LPC1768)
DigitalIn joy_down(p12, PullDown);
DigitalIn joy_left(p13, PullDown);
DigitalIn joy_center(p14, PullDown);
DigitalIn joy_up(p15, PullDown);
DigitalIn joy_right(p16, PullDown);

// Helper: detect a new button press (falling edge 1 -> 0).
// Assumes: 1 = released (pull-up), 0 = pressed.
bool pressed_edge(DigitalIn &btn, int &last) {
    int now = btn.read(); 
    bool edge = (last == 1 && now == 0);
    last = now;
    return edge;
}

int main() {
    // Start with all LEDs OFF
    //led1 = led2 = led3 = led4 = 0;

    // Store previous button states
    int last_left = 1, last_up = 1, last_right = 1, last_down = 1, last_center = 1;

    // Loop: check joystick every 20 ms (debounce). 
    // On a new press, toggle the matching LED. Center press clears all LEDs.
    while (true) {
        wait_ms(20);

        if (pressed_edge(joy_left,  last_left))   led1 = !led1;
        if (pressed_edge(joy_up,    last_up))     led2 = !led2;
        if (pressed_edge(joy_right, last_right))  led3 = !led3;
        if (pressed_edge(joy_down,  last_down))   led4 = !led4;

        if (pressed_edge(joy_center, last_center)) {
            // Center press: turn OFF all LEDs
            led1 = led2 = led3 = led4 = 0;
        }
    }
}
