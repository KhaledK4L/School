var indexSectionsWithContent =
{
  0: "befk",
  1: "b",
  2: "befk"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Pages"
};

