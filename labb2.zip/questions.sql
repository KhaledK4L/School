USE Filmbutik;
#visa alla filmer

#visa alla filmer som INTE är längre än 120 min
SELECT titel,filmlangd FROM Filmbutik.Film
WHERE filmlangd <= 120;

#visa alla medlemmar vars förnamn börjar på H
SELECT f_namn, e_namn FROM Filmbutik.Medlem
WHERE f_namn LIKE 'H%';

#visa alla medlemmar som gick med mellan 2024-09-14 och 2024-09-22
SELECT f_namn, e_namn, startdatum FROM Filmbutik.Medlem
WHERE startdatum BETWEEN '2024-09-14' AND '2024-09-22';

#visa butik som har fler än 1 anställd

SELECT butiks_id, COUNT(*) AS antal_anstallda
FROM Filmbutik.Anstalld
GROUP BY butiks_id
HAVING COUNT(*) > 1;

# en fråga med order by, visa alla filmer sorterade efter längd, längst först
SELECT titel, filmlangd FROM Filmbutik.Film ORDER BY filmlangd DESC;

#TA BORT ALLA MEDLEMMAR SOM BOR I MALMÖ
SELECT medlemnummer, f_namn, e_namn, stad FROM Filmbutik.Medlem WHERE stad = 'Malmö';

DELETE FROM Filmbutik.Medlem
WHERE stad = 'Malmö';

#uppdater lönen för shadi dirawi till 62000 (denna använder update)
UPDATE Filmbutik.Anstalld SET lon = 62000
WHERE f_namn = 'Salem' AND e_namn = 'Barqawi';


# lista de butiker som har filmer med högre pris än genomsnittet
SELECT b.namn, e.pris FROM Filmbutik.Erbjuder e JOIN Filmbutik.butik AS b ON b.butiks_id = e.butiks_id
WHERE e.pris > ( SELECT AVG (pris) FROM Filmbutik.Erbjuder
);

#lista ut alla anstallda
SELECT * FROM Filmbutik.Anstalld;

#lsita ut alla som arbetar
SELECT* FROM filmbutik.Arbetar_med;
