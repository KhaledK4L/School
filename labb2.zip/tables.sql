CREATE DATABASE Filmbutik
    CHARACTER SET utf8mb4;

USE Filmbutik;

CREATE TABLE Butik (
    butiks_id INT,
    namn VARCHAR(120) NOT NULL,
    stad VARCHAR(80),
    telefonnummer VARCHAR(30),
    gata VARCHAR(120),
    postnummer VARCHAR(10),
    husnummer VARCHAR(10)
);

CREATE TABLE Anstalld (
    anstallnings_id INT ,
    butiks_id INT NOT NULL,
    f_namn VARCHAR(60) NOT NULL,
    e_namn VARCHAR(60) NOT NULL,
    lon DECIMAL(10,2),
    roll VARCHAR(60)
);

CREATE TABLE Medlem (
    medlemnummer INT,
    butiks_id INT NOT NULL,
    f_namn VARCHAR(60) NOT NULL,
    e_namn VARCHAR(60) NOT NULL,
    stad VARCHAR(40),
    husnummer VARCHAR(10),
    gata VARCHAR(120),
    startdatum DATE NOT NULL
);

CREATE TABLE Film (
    filmnummer INT ,
    titel VARCHAR(150),
    filmlangd INT NOT NULL
);
CREATE TABLE FilmIButik (
    filmnummer INT,
    butiks_id INT,
    antal INT
 );
CREATE TABLE Filmpersonal (
    anstallnings_id INT,
    f_namn VARCHAR(50),
    e_namn VARCHAR(60)
);

CREATE TABLE Film_genre (
    filmnummer INT NOT NULL,
    genre_id INT NOT NULL
);

CREATE TABLE Genre (
    genre_id INT NOT NULL,
    genre VARCHAR (60)
);

CREATE TABLE Erbjuder (
    butiks_id INT NOT NULL,
    filmnummer INT NOT NULL,
    pris DECIMAL(10,2),
    hyllnamn VARCHAR(80),
    antal INT,
    status VARCHAR(50)
);

CREATE TABLE Arbetar_med (
    filmnummer INT NOT NULL,
    anstallnings_id INT NOT NULL,
    roll VARCHAR(50)
);

CREATE TABLE Hyr (
    medlemnummer INT,
    butiks_id INT NOT NULL,
    filmnummer INT NOT NULL,
    uthyrningsdatum DATE NOT NULL,
    aterlamningsdatum DATE
);

CREATE TABLE Reservering (
    medlemnummer INT,
    filmnummer INT,
    reserveringsdatum DATE NOT NULL,
    senast_onskat_datum DATE NOT NULL,
    giltig_tom DATE NOT NULL
);