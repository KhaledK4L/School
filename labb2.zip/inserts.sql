

INSERT INTO Butik (namn, stad, telefonnummer, gata, husnummer, postnummer) VALUES
 ('Film-kissen',     'Sundsvall', '039-121212', 'Kissegatan',  '10', '856 45'),
 ('Simbasfilmhörna', 'Stockholm', '040-131313', 'Simbagatan', '12', '111 57'),
 ('Drakstaden',      'Umeå',      '050-676767', 'Umeåvägen', '13', '901 30'),
 ('Filmvärlden',     'Malmö',     '090-123456', 'Malmövägen', '4',  '211 09');

INSERT INTO Anstalld (roll, f_namn, e_namn, lon, butiks_id) VALUES
 ('Butikschef',    'Khaled',   'Hamza',     77900.00, 1),
 ('Kassapersonal', 'Philip',  'Svenson',     60500.00, 1),
 ('Ekonom',        'Peter',  'Samy',      88900.00, 2),
 ('Ekonom',        'Salem',  'Barqawi',     99000.00, 3),
 ('Tekniker',      'Emma', 'Johansson', 100000.00, 4);

INSERT INTO Medlem (medlemnummer, butiks_id, f_namn, e_namn, stad, gata, husnummer, startdatum) VALUES
 ('321', 1, 'Anna',     'Andersson', 'Sundsvall', 'Hagavägen',      '12', '2024-09-13'),
 ('534', 2, 'Håkan',    'Hellström', 'Stockholm', 'Strandgatan',    '58', '2024-09-20'),
 ('477', 3, 'Veronika', 'Aspberg',   'Umeå',      'Språkgränd',     '18', '2024-09-21'),
 ('537', 4, 'Hamid',    'Abdulla',   'Malmö',     'Sorgenfrivägen', '55', '2024-09-22');

INSERT INTO Film (titel, filmlangd) VALUES
 ('The Conjuring: Last Rites', 135),
 ('Pretty Woman',  119),
 ('White Chicks',  109),
 ('Grown Ups',102),
 ('Happy Gilmore', 93),
 ('Rango', 107),
 ('Divergent', 139);

INSERT INTO Genre (genre_id, genre) VALUES
 (1, 'Comedy'),
(2, 'Drama'),
(3, 'Kriminal'),
(4, 'Sport'),
(5, 'Sci-fi'),
(6, 'Adventure'),
(7, 'Action'),
(8, 'Thriller'),
(9, 'Horror');



INSERT INTO Film_genre (filmnummer, genre_id) VALUES
    (1, 1), (1, 3),
    (2, 3),(2, 5),
    (3, 4), (3, 1),
    (4, 9), (4, 4),
    (5, 8),(5, 2),
    (6, 7), (6, 6),
    (7, 1), (7, 3),
    (7, 4),(7, 7);

INSERT INTO Filmpersonal (f_namn, e_namn) VALUES
    ('Nina', 'Eriksson'),
    ('Hannah', 'Elnour'),
    ('Svea', 'Svensson'),
    ('Bella', 'Hadid'),
    ('Max', 'Kjellström'),
    ('Sven', 'Palm'),
    ('John', 'Nordström'),
    ('Erik', 'Eriksson'),
    ('Charlie', 'Hederberg'),
    ('Elsa', 'Holm'),
    ('Katrin', 'Strömqvist'),
    ('Linnea', 'Andersson'),
    ('Hassan', 'Al-deen'),
    ('Jasmine', 'Khatar'),
    ('Astrid', 'Söderström');

INSERT INTO Erbjuder (butiks_id, filmnummer, pris, hyllnamn, antal, Status) VALUES

(1, 1,39.00, 'A1', 3, 'I lager' ),
(1,2, 29.00, 'A2', 4, 'I lager'),
(1,3, 25.00,'A2', 2, 'I lager'),
(1, 7, 35.00, 'A3', 3, 'I lager'),


(2,2, 32.00, 'B1', 5, 'I lager'),
(2, 5,28.00, 'B2', 2, 'I lager' ),
(2, 6, 31.00, 'B3', 3, 'I lager' ),
(2, 7, 36.00, 'B4', 2, 'I lager'),


(3,1,40.00, 'C1', 1, 'I lager'),
(3, 3, 27.00, 'C2', 5, 'I lager'),
(3,4,33.00, 'C3', 4, 'I lager'),
(3,6, 30.00, 'C4',3, 'I lager'),


(4,1,38.00, 'D1', 2, 'I lager'),
(4,4,34.00, 'D2', 3, 'I lager'),
(4, 5, 26.00, 'D3', 5, 'I lager'),
(4,6 , 29.00, 'D4', 6, 'I lager');


INSERT INTO Arbetar_med (filmnummer, anstallnings_id, roll) VALUES
    (1, 5,  'Skådespelare'),
    (1, 5,  'Regissör'),
    (2, 7,  'Skådespelare'),
    (2, 7,  'Kamera & Ljus'),
    (3, 9,  'Skådespelare'),
    (3, 9,  'Ljudtekniker'),
    (4, 1,  'Skådespelare'),
    (4, 1,  'Regissör'),
    (5, 2,  'Skådespelare'),
    (5, 2, 'Ljudtekniker'),
    (6, 3, 'Skådespelare'),
    (6, 3, 'Producent'),
    (7, 4, 'Casting-ansvarig'),
    (7, 4, 'Skådespelare'),
    (7, 4, 'Manusförfattare');
